import java.lang.*;
import javax.swing.*;


public class ReceptionistFrame extends JFrame
{
	JLabel pnLabel, docLabel, tLabel, specLabel;
	JTextField pnTF, docTF, tTF;
	JButton sBtn, addBtn, uBtn, rBtn;
	JComboBox scombo;
	JPanel panel;
	
	public ReceptionistFrame()
	{
		super("Reception");
		this.setSize(800, 450);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		pnLabel = new JLabel("Patient Name : ");
		pnLabel.setBounds(30, 50, 100, 20);
		panel.add(pnLabel);
		
		pnTF = new JTextField();
		pnTF.setBounds(125, 50, 100, 20);
		panel.add(pnTF);
		
		docLabel = new JLabel("Doctor's name : ");
		docLabel.setBounds(30, 100, 100, 20);
		panel.add(docLabel);
		
		docTF = new JTextField();
		docTF.setBounds(125, 100, 100, 20);
		panel.add(docTF);
		
		tLabel = new JLabel("Time : ");
		tLabel.setBounds(30, 150, 100, 20);
		panel.add(tLabel);
		
		tTF = new JTextField();
		tTF.setBounds(125, 150, 100, 30);
		panel.add(tTF);
		
		specLabel = new JLabel("Specialist : ");
		specLabel.setBounds(30, 200, 100, 20);
		panel.add(specLabel);
		
		String items[] = {"Neurologist", "Cardiology", "Orthopedic", "ENT", "Nephrologist"};
		scombo = new JComboBox(items);
		scombo.setBounds(125, 200, 100, 20);
		panel.add(scombo);
		
		sBtn = new JButton("Search");
		sBtn.setBounds(400, 265, 80, 30);
		panel.add(sBtn);
		
		
		addBtn = new JButton("Add");
		addBtn.setBounds(500, 265, 80, 30);
		panel.add(addBtn);
		
		uBtn = new JButton("Update");
		uBtn.setBounds(600, 265, 80, 30);
		panel.add(uBtn);
		
		rBtn = new JButton("Remove");
		rBtn.setBounds(700, 265, 80, 30);
		panel.add(rBtn);
		

		
		this.add(panel);
		
		}
	
}