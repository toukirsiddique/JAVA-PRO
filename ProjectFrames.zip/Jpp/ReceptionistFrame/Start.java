import java.lang.*;

public class Start
{
	public static void main(String args[])
	{
		ReceptionistFrame rf = new ReceptionistFrame();
		rf.setVisible(true);
	}
}