import java.lang.*;
import javax.swing.*;


public class ManagerFrame extends JFrame
{
	JLabel idLabel, nLabel, slLabel, postLabel;
	JTextField idTF, nTF, slTF;
	JButton sBtn, addBtn, uBtn, rBtn;
	JComboBox pcombo;
	JPanel panel;
	
	public ManagerFrame()
	{
		super("Manager");
		this.setSize(800, 450);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		idLabel = new JLabel("ID : ");
		idLabel.setBounds(30, 50, 100, 20);
		panel.add(idLabel);
		
		idTF = new JTextField();
		idTF.setBounds(100, 50, 100, 20);
		panel.add(idTF);
		
		nLabel = new JLabel("Name : ");
		nLabel.setBounds(30, 100, 100, 20);
		panel.add(nLabel);
		
		nTF = new JTextField();
		nTF.setBounds(100, 100, 100, 20);
		panel.add(nTF);
		
		slLabel = new JLabel("Salary : ");
		slLabel.setBounds(30, 150, 100, 20);
		panel.add(slLabel);
		
		slTF = new JTextField();
		slTF.setBounds(100, 150, 100, 30);
		panel.add(slTF);
		
		postLabel = new JLabel("Designation : ");
		postLabel.setBounds(30, 200, 100, 20);
		panel.add(postLabel);
		
		String items[] = {"Receptionist", "Doctor"};
		pcombo = new JComboBox(items);
		pcombo.setBounds(100, 200, 100, 20);
		panel.add(pcombo);
		
		sBtn = new JButton("Search");
		sBtn.setBounds(400, 265, 80, 30);
		panel.add(sBtn);
		
		
		addBtn = new JButton("Add");
		addBtn.setBounds(500, 265, 80, 30);
		panel.add(addBtn);
		
		uBtn = new JButton("Update");
		uBtn.setBounds(600, 265, 80, 30);
		panel.add(uBtn);
		
		rBtn = new JButton("Remove");
		rBtn.setBounds(700, 265, 80, 30);
		panel.add(rBtn);
		

		
		this.add(panel);
		
		}
	
}