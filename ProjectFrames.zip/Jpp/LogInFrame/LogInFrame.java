import java.lang.*;
import javax.swing.*;
import java.awt.*;

public class LogInFrame extends JFrame
{
	ImageIcon img;
	JLabel userLabel, passLabel, imgLabel;
	JTextField userTF;
	JPasswordField passPF;
	JButton loginBtn, exitBtn;
	JPanel panel;
	Color myColor;
	//Font myFont;

	public LogInFrame()
	{
		super("LogIn page");
		this.setSize(800, 450);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		userLabel = new JLabel("User ID : ");
		userLabel.setBounds(210, 115, 100, 30);
		panel.add(userLabel);
		
		userTF = new JTextField();
		userTF.setBounds(310, 115, 200, 30);
		panel.add(userTF);
		
		passLabel = new JLabel("Password : ");
		passLabel.setBounds(210, 165, 100, 30);
		panel.add(passLabel);
		
		
		passPF = new JPasswordField();
		passPF.setBounds(310, 165, 200, 30);
		passPF.setEchoChar('*');
		panel.add(passPF);
		
		loginBtn = new JButton("Login");
		loginBtn.setBounds(280, 230, 150, 30);
		loginBtn.setBackground(Color.GREEN);
		panel.add(loginBtn);
		
		
		exitBtn = new JButton("Cancel");
		exitBtn.setBounds(280, 280, 150, 30);
		exitBtn.setBackground(Color.RED);
		panel.add(exitBtn);
		
		
		
		
		
		
		//img = new ImageIcon("oop1g.jpg");
		//imgLabel = new JLabel(img);
		//imgLabel.setBounds(450, 150, 200, 112);
		//panel.add(imgLabel);
		
		this.add(panel);
	}
	
}