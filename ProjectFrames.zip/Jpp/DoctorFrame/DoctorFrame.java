import java.lang.*;
import javax.swing.*;
import java.awt.*;


public class DoctorFrame extends JFrame
{
    JLabel acceptLabel, timeLabel;
    JButton sBtn, addBtn, uBtn, rBtn;
	JRadioButton r1, r2;
    JComboBox scombo;
	ButtonGroup bg1;
    JPanel panel;
	//Font myFont;

    public DoctorFrame()
    {
        super("Doctor's panel");
        this.setSize(800, 450);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);
		
		acceptLabel = new JLabel("Accept? : ");
		acceptLabel.setBounds(30, 50, 100, 20);
		panel.add(acceptLabel);
       
	   

        r1 = new JRadioButton("YES");
		r1.setBounds(100, 50, 100, 20);
		panel.add(r1);
		
		r2 = new JRadioButton("NO");
		r2.setBounds(200, 50, 100, 20);
		panel.add(r2);
		
		
		bg1 = new ButtonGroup();
		bg1.add(r1);
		bg1.add(r2);
		
		timeLabel = new JLabel("Time : ");
		timeLabel.setBounds(30, 100, 100, 20);
		panel.add(timeLabel);
		

        String items[] = {"10:00 a.m", "12:00 p.m", "1 p.m", "2 p.m", "6 p.m"};
        scombo = new JComboBox(items);
        scombo.setBounds(80, 100, 100, 20);
        panel.add(scombo);
		
		
		sBtn = new JButton("Search");
        sBtn.setBounds(400, 265, 80, 30);
        panel.add(sBtn);


        addBtn = new JButton("Add");
        addBtn.setBounds(500, 265, 80, 30);
        panel.add(addBtn);

        uBtn = new JButton("Update");
        uBtn.setBounds(600, 265, 80, 30);
        panel.add(uBtn);

        rBtn = new JButton("Remove");
        rBtn.setBounds(700, 265, 80, 30);
        panel.add(rBtn);

        this.add(panel);

        }

}