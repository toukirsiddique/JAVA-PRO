import java.lang.*;

public class Start
{
	public static void main(String args[])
	{
		DoctorFrame df = new DoctorFrame();
		df.setVisible(true);
	}
}