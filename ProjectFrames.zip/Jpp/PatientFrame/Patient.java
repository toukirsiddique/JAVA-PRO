import java.lang.*;
import javax.swing.*;


public class Patient extends JFrame
{
	JLabel pnLabel, docLabel, tLabel, specLabel;
	JTextField pnTF, docTF, tTF;
	JButton sBtn, addBtn;
	JComboBox scombo;
	JPanel panel;
	
	public Patient()
	{
		super("patient");
		this.setSize(800, 450);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		pnLabel = new JLabel("Patient Name : ");
		pnLabel.setBounds(150, 115, 100, 30);
		panel.add(pnLabel);
		
		pnTF = new JTextField();
		pnTF.setBounds(280, 115, 100, 30);
		panel.add(pnTF);
		
		docLabel = new JLabel("Doctor's name : ");
		docLabel.setBounds(150, 165, 100, 30);
		panel.add(docLabel);
		
		docTF = new JTextField();
		docTF.setBounds(280, 165, 100, 30);
		panel.add(docTF);
		
		tLabel = new JLabel("Time : ");
		tLabel.setBounds(150, 215, 100, 30);
		panel.add(tLabel);
		
		tTF = new JTextField();
		tTF.setBounds(280, 215, 100, 30);
		panel.add(tTF);
		
		specLabel = new JLabel("Specialist : ");
		specLabel.setBounds(150, 265, 100, 30);
		panel.add(specLabel);
		
		String items[] = {"Neurologist", "Cardiology", "Orthopedic", "ENT", "Nephrologist"};
		scombo = new JComboBox(items);
		scombo.setBounds(280, 265, 100, 30);
		panel.add(scombo);
		
		sBtn = new JButton("Search");
		sBtn.setBounds(400, 265, 80, 30);
		panel.add(sBtn);
		
		
		addBtn = new JButton("Add");
		addBtn.setBounds(500, 265, 80, 30);
		panel.add(addBtn);
		
		this.add(panel);
		
		}
	
}